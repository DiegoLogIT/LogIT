﻿using System;
namespace PointOfSale.Models
{
	public enum ItemCategory
	{
		Noodles,
		Rice,
		Appetizers,
		Desserts,
		Beverages
	}
}

