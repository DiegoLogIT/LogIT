﻿namespace PointOfSale.Pages;

public partial class EmptyPage : ContentPage
{
	public EmptyPage()
	{
		InitializeComponent();
	}
}
