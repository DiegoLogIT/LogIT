﻿namespace PointOfSale.Pages.Views;

public partial class OrderCartView : ContentView
{
	public OrderCartView()
	{
		InitializeComponent();
	}
}
