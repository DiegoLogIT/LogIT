﻿namespace PointOfSale.Pages;

public partial class AddProductView
{
	public AddProductView()
	{
		InitializeComponent();
	}
}
