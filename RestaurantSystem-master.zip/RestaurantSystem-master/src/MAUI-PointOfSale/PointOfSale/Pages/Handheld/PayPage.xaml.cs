﻿using SkiaSharp;
using SkiaSharp.Views.Maui;

namespace PointOfSale.Pages.Handheld;

public partial class PayPage : ContentPage
{
    public PayPage()
	{
		InitializeComponent();
	}
}
