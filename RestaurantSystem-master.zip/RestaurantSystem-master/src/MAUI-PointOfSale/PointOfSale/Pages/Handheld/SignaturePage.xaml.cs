﻿namespace PointOfSale.Pages.Handheld;

public partial class SignaturePage : ContentPage
{
	public SignaturePage()
	{
		InitializeComponent();
	}

}
