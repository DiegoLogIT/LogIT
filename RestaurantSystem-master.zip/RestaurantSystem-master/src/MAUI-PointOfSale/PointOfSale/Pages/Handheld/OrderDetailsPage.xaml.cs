﻿namespace PointOfSale.Pages.Handheld;

public partial class OrderDetailsPage : ContentPage
{
	public OrderDetailsPage()
	{
		InitializeComponent();
	}
}
