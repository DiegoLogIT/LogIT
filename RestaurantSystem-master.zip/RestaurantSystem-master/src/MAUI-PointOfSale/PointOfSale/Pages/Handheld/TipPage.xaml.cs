﻿namespace PointOfSale.Pages.Handheld;

public partial class TipPage : ContentPage
{
	public TipPage()
	{
		InitializeComponent();
	}
}
