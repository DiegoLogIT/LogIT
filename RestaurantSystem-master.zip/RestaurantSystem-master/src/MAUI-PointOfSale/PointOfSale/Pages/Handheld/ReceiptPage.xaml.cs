﻿namespace PointOfSale.Pages.Handheld;

public partial class ReceiptPage : ContentPage
{
	public ReceiptPage()
	{
		InitializeComponent();
	}
}
