﻿namespace PointOfSale.Pages.Handheld;

public partial class OrdersPage : ContentPage
{
	public OrdersPage()
	{
		InitializeComponent();
	}
}
