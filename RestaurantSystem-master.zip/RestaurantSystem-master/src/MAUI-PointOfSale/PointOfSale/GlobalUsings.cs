global using System.Collections.ObjectModel;
global using System.Diagnostics;
global using CommunityToolkit.Mvvm;
global using CommunityToolkit.Mvvm.ComponentModel;
global using CommunityToolkit.Mvvm.Input;
global using PointOfSale.Models;
global using CommunityToolkit.Mvvm.Messaging;