<?php require 'header/menu.php'; ?>
<br>
<section>
	<?php 
	$mvc=new MvcController();
	$mvc->enlacesPaginasController();
	 ?>
</section>


<?php require 'header/footer.php'; ?>