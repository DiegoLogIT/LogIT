﻿Public Class mainForm
    Private Sub RegistroDeProductosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistroDeProductosToolStripMenuItem.Click
        productoForm.Show()
    End Sub
End Class