﻿Imports System.Data.OleDb
Module config
    Public cmd As New OleDbCommand
    Public ddt As New OleDbDataAdapter
    Public dtd As New DataTable

    Public Function conn() As OleDbConnection
        Return New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\tcs.mdb")
    End Function
    Public con As OleDbConnection = conn()

End Module
