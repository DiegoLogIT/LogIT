﻿Imports System.Data.OleDb
Public Class Form1
    Dim con As New OleDbConnection
    Dim cmd As New OleDbCommand
    Dim ddt As New OleDbDataAdapter
    Dim dtd As New DataSet
    Dim btn() As Button
    Dim i As Integer
    Dim loc As New Point(10, 10)
#Region "button creation"
    Private Sub bf()
        Panel1.Controls.Clear()
        loc.Y = Nothing
        loc.X = Nothing
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Dim ddt As New OleDbDataAdapter
        Dim dtd As New DataSet
        con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
        cmd.CommandText = "SELECT * from bfi order by itc"
        cmd.Connection = con
        ddt.SelectCommand = cmd
        ddt.Fill(dtd, "0")
        Dim cnt = (dtd.Tables(0).Rows.Count - 1)
        Dim i As Short
        ReDim btn(cnt)
        For i = 0 To cnt
            btn(i) = New Button
            With btn(i)
                .Size = New Point(150, 27)
                .Name = "Button" & i
                .Text = dtd.Tables(0).Rows(i)(1)
                .BackColor = Color.BurlyWood
                .Location = loc
                .TabStop = False
                loc.Y += 50
                AddHandler .Click, AddressOf btn_click
            End With
        Next
        Me.Panel1.Controls.AddRange(btn)
    End Sub
    Private Sub btn_click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        TextBox1.Text = sender.text ' this block of code sends the name of the button for further action
        TextBox2.Focus()
    End Sub
    Private Sub lun()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Dim ddt As New OleDbDataAdapter
        Dim dtd As New DataSet
        Panel1.Controls.Clear()
        loc.Y = Nothing
        loc.X = Nothing
        con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
        cmd.CommandText = "SELECT * from lun order by itc"
        cmd.Connection = con
        ddt.SelectCommand = cmd
        ddt.Fill(dtd, "0")
        Dim cnt = (dtd.Tables(0).Rows.Count - 1)
        Dim i As Short
        ReDim btn(cnt)
        For i = 0 To cnt
            btn(i) = New Button
            With btn(i)
                .Size = New Point(150, 27)
                .Name = "Button" & i
                .Text = dtd.Tables(0).Rows(i)(1)
                .BackColor = Color.BurlyWood
                .Location = loc
                .TabStop = False
                loc.Y += 50
                AddHandler .Click, AddressOf btn_click
            End With
        Next
        Me.Panel1.Controls.AddRange(btn)
    End Sub
    Private Sub dinn()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Dim ddt As New OleDbDataAdapter
        Dim dtd As New DataSet
        Panel1.Controls.Clear()
        loc.Y = Nothing
        loc.X = Nothing
        con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
        cmd.CommandText = "SELECT * from din order by itc"
        cmd.Connection = con
        ddt.SelectCommand = cmd
        ddt.Fill(dtd, "0")
        Dim cnt = (dtd.Tables(0).Rows.Count - 1)
        Dim i As Short
        ReDim btn(cnt)
        For i = 0 To cnt
            btn(i) = New Button
            With btn(i)
                .Size = New Point(150, 27)
                .Name = "Button" & i
                .Text = dtd.Tables(0).Rows(i)(1)
                .BackColor = Color.BurlyWood
                .Location = loc
                .TabStop = False
                loc.Y += 50
                AddHandler .Click, AddressOf btn_click
            End With
        Next
        Me.Panel1.Controls.AddRange(btn)
    End Sub
    Private Sub com()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Dim ddt As New OleDbDataAdapter
        Dim dtd As New DataSet
        Panel1.Controls.Clear()
        loc.Y = Nothing
        loc.X = Nothing
        con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
        cmd.CommandText = "SELECT * from cmn order by itc"
        cmd.Connection = con
        ddt.SelectCommand = cmd
        ddt.Fill(dtd, "0")
        Dim cnt = (dtd.Tables(0).Rows.Count - 1)
        Dim i As Short
        ReDim btn(cnt)
        For i = 0 To cnt
            btn(i) = New Button
            With btn(i)
                .Size = New Point(150, 27)
                .Name = "Button" & i
                .Text = dtd.Tables(0).Rows(i)(1)
                .BackColor = Color.BurlyWood
                .Location = loc
                .TabStop = False
                loc.Y += 50
                AddHandler .Click, AddressOf btn_click
            End With
        Next
        Me.Panel1.Controls.AddRange(btn)
    End Sub
#End Region
#Region "Textbox change events"
    Private Sub bft()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Dim ddt As New OleDbDataAdapter
        Dim dtd As New DataSet
        Dim i As New Integer
        con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
        cmd.CommandText = "SELECT * from bfi where itn='" & TextBox1.Text & "' "
        cmd.Connection = con
        ddt.SelectCommand = cmd
        ddt.Fill(dtd, "0")
        Dim cnt = dtd.Tables(0).Rows.Count
        If cnt > 0 Then
            TextBox1.Text = dtd.Tables(0).Rows(i)(1).ToString
            TextBox3.Text = dtd.Tables(0).Rows(i)(2).ToString
            TextBox4.Text = dtd.Tables(0).Rows(i)(3).ToString
            Label9.Text = dtd.Tables(0).Rows(i)(0).ToString
        End If
    End Sub
    Private Sub lut()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Dim ddt As New OleDbDataAdapter
        Dim dtd As New DataSet
        Dim i As New Integer
        Dim i1 As New Integer
        con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
        cmd.CommandText = "SELECT * from lun where itn='" & TextBox1.Text & "' "
        cmd.Connection = con
        ddt.SelectCommand = cmd
        ddt.Fill(dtd, "0")
        Dim cnt = dtd.Tables(0).Rows.Count
        If cnt > 0 Then
            TextBox1.Text = dtd.Tables(0).Rows(i)(1).ToString
            TextBox3.Text = dtd.Tables(0).Rows(i)(2).ToString
            TextBox4.Text = dtd.Tables(0).Rows(i)(3).ToString
            Label9.Text = dtd.Tables(0).Rows(i)(0).ToString
        End If
    End Sub
    Private Sub din()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Dim ddt As New OleDbDataAdapter
        Dim dtd As New DataSet
        Dim i As New Integer
        con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
        cmd.CommandText = "SELECT * from din where itn='" & TextBox1.Text & "' "
        cmd.Connection = con
        ddt.SelectCommand = cmd
        ddt.Fill(dtd, "0")
        Dim cnt = dtd.Tables(0).Rows.Count
        If cnt > 0 Then
            TextBox1.Text = dtd.Tables(0).Rows(i)(1).ToString
            TextBox3.Text = dtd.Tables(0).Rows(i)(2).ToString
            TextBox4.Text = dtd.Tables(0).Rows(i)(3).ToString
            Label9.Text = dtd.Tables(0).Rows(i)(0).ToString
        End If
    End Sub
    Private Sub cmn()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        Dim ddt As New OleDbDataAdapter
        Dim dtd As New DataSet
        Dim i As New Integer
        con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
        cmd.CommandText = "SELECT * from cmn where itn='" & TextBox1.Text & "' "
        cmd.Connection = con
        ddt.SelectCommand = cmd
        ddt.Fill(dtd, "0")
        Dim cnt = dtd.Tables(0).Rows.Count
        If cnt > 0 Then
            TextBox1.Text = dtd.Tables(0).Rows(i)(1).ToString
            TextBox3.Text = dtd.Tables(0).Rows(i)(2).ToString
            Label9.Text = dtd.Tables(0).Rows(i)(0).ToString
        End If
    End Sub
#End Region
#Region "Calculation"
    Dim calc As New Integer
    Dim i1 As New Integer
    Dim i2 As New Integer
    Dim tl As New Integer

    Private Sub cal()
        i1 = TextBox3.Text
        i2 = TextBox2.Text
        calc = i1 * i2
        Dim lst As New ListViewItem(TextBox1.Text)
        lst.SubItems.Add(TextBox3.Text)
        lst.SubItems.Add(TextBox2.Text)
        lst.SubItems.Add(calc.ToString)
        ListView1.Items.Add(lst)
    End Sub
    Private Sub bal()
        Try
            Dim i1, i2, i3 As New Integer
            i1 = TextBox6.Text
            i2 = TextBox5.Text
            i3 = i2 - i1
            TextBox7.Text = i3.ToString
        Catch
            If TextBox6.Text = "" Then
                MessageBox.Show("No items to bill", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBox6.Focus()
            ElseIf TextBox7.Text = "" Then
                MessageBox.Show("No amount entered", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End Try
    End Sub

   
#End Region
#Region "Sumup the price"
    Public Function tot() As Double
        Dim k As Integer = 0
        Try
            Dim j As Integer = ListView1.Items.Count
            Dim i As Integer
            For i = 0 To j - 1
                k += CType(ListView1.Items(i).SubItems(3).Text, Integer)
            Next
        Catch ex As Exception

        End Try
        Return k
    End Function
#End Region
#Region "Error cheking and cleaning"
    Sub cln()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub
    Sub err()
        If (TextBox2.Text = "" Or TextBox1.Text = "" Or TextBox3.Text = "") Then
            MessageBox.Show("Enter the required fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Call cal()
            Call cln()
        End If

    End Sub
#End Region

#Region "Adding New item , updating item and delete item"
   
    Private Sub insert()
        Try
            Dim cmd1 As New OleDbCommand
            con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
            Select Case ComboBox1.SelectedIndex
                Case 0
                    cmd1.CommandText = "INSERT INTO bfi(itn,itp,remarks) VALUES(@itn,@itp,@remarks)"
                Case 1
                    cmd1.CommandText = "INSERT INTO lun(itn,itp,remarks) VALUES(@itn,@itp,@remarks)"
                Case 2
                    cmd1.CommandText = "INSERT INTO din(itn,itp,remarks) VALUES(@itn,@itp,@remarks)"
                Case 3
                    cmd1.CommandText = "INSERT INTO cmn(itn,itp) VALUES(@itn,@itp)"
            End Select
            cmd1.Connection = con
            con.Open()
            cmd1.Parameters.AddWithValue("@itn", TextBox1.Text)
            cmd1.Parameters.AddWithValue("@itp", TextBox3.Text)
            cmd1.Parameters.AddWithValue("@remarks", TextBox4.Text)
            cmd1.ExecuteNonQuery()
            con.Close()
            MessageBox.Show("New Item Added, Please select the Catagory again to make the addition available", "New Item Added", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch
            MessageBox.Show("Check For empty fields or wait for technician to arrive, Error Code:101", "Error Generated", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
       
    End Sub
    Private Sub up()
       
        Try
            Dim cmd2 As New OleDbCommand
            con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
            Select Case ComboBox1.SelectedIndex
                Case 0
                    cmd2.CommandText = "update bfi set itn=@p1,itp=@p2,remarks=@p3 where itc=@p4"
                Case 1
                    cmd2.CommandText = "update lun set itn=@p1,itp=@p2,remarks=@p3 where itc=@p4"
                Case 2
                    cmd2.CommandText = "update din set itn=@p1,itp=@p2,remarks=@p3 where itc=@p4"
            End Select
            cmd2.Connection = con
            con.Open()
            cmd2.Parameters.AddWithValue("@p1", TextBox1.Text)
            cmd2.Parameters.AddWithValue("@p2", TextBox3.Text)
            cmd2.Parameters.AddWithValue("@p3", TextBox4.Text)
            cmd2.Parameters.AddWithValue("@p4", Label9.Text)
            cmd2.ExecuteNonQuery()
            MsgBox("Success")
            con.Close()
            MessageBox.Show("Item Updated, Please reselect the catagory to avail the changes.", "Item Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch
            MessageBox.Show("Check For empty fields or wait for technician to arrive, Error Code:102", "Error Generated", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
    Private Sub cup()
        Try
            Dim cmd3 As New OleDbCommand
            con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
            cmd3.CommandText = "update cmn set itn=@p1,itp=@p2 where itc=@p4"
            cmd3.Connection = con
            con.Open()
            cmd3.Parameters.AddWithValue("@p1", TextBox1.Text)
            cmd3.Parameters.AddWithValue("@p2", TextBox3.Text)
            cmd3.Parameters.AddWithValue("@p4", Label9.Text)
            cmd3.ExecuteNonQuery()
            MsgBox("Success")
            con.Close()
            MessageBox.Show("Item Updated, Please reselect the catagory to avail the changes.", "Item Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch
            MessageBox.Show("Check For empty fields or wait for technician to arrive, Error Code:103", "Error Generated", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        
    End Sub
    Private Sub del()
        Try
            Dim cmd4 As New OleDbCommand
            con.ConnectionString = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\tcs.mdb")
            cmd4.Connection = con
            con.Open()
            Select Case ComboBox1.SelectedIndex
                Case 0
                    cmd4.CommandText = "Delete from bfi where itn='" & TextBox1.Text & "'"
                Case 1
                    cmd4.CommandText = "Delete from lun where itn='" & TextBox1.Text & "'"
                Case 2
                    cmd4.CommandText = "Delete from din where itn='" & TextBox1.Text & "'"
                Case 3
                    cmd4.CommandText = "Delete from cmn where itn='" & TextBox1.Text & "'"
            End Select
            cmd4.ExecuteNonQuery()
            MessageBox.Show("Item is Removed, Please rreselect the catagory to avail the changes", "Item Removed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Check For Item name and try again or wait for technician to arrive, Error Code:104", "Error Generated", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "Button Click events"
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.TopMost = True
    End Sub
    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.Shift AndAlso e.KeyCode = Keys.Z Then
            Call bal()
            Beep()
        End If
        If e.KeyValue = Keys.F3 Then
            ListView1.FocusedItem.Remove()
            Beep()
        End If
        If e.Shift AndAlso e.KeyCode = Keys.X Then
            Beep()
            End
        End If
        If e.KeyValue = Keys.Enter Then
            Beep()
        End If
    End Sub
    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Call cln()
        Select Case ComboBox1.SelectedIndex ' see button creation region
            Case 0
                Call bf()
            Case 1
                Call lun()
            Case 2
                Call dinn()
            Case 3
                Call com()
        End Select
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click, Button13.Click
        Call err()
        TextBox6.Text = tot()
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click, Button14.Click
        Call bal()
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click, Button12.Click
        If ListView1.Items.Count = 0 Then
            MessageBox.Show("No item to remove", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            ListView1.FocusedItem.Remove()
        End If
    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click, Button11.Click
        insert()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click, Button10.Click
        If TextBox1.Text = "" Then
            MessageBox.Show("Please select items to update", "Error Updating", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)
        Else
            Select Case ComboBox1.SelectedIndex
                Case 0
                    Call up()
                Case 1
                    Call up()
                Case 2
                    Call up()
                Case 3
                    Call cup()
            End Select
        End If

    End Sub
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click, Button9.Click
        Call del()
    End Sub
    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        End
    End Sub
    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Select Case ComboBox1.SelectedIndex
            Case 0
                Call bft()
            Case 1
                Call lut()
            Case 2
                Call din()
            Case 3
                Call cmn()
        End Select

    End Sub
    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar <> ChrW(Keys.Back) Then
            If (e.KeyChar.ToString >= "0" And e.KeyChar.ToString <= "9") Then
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox5_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox5.KeyPress
        If e.KeyChar <> ChrW(Keys.Back) Then
            If (e.KeyChar.ToString >= "0" And e.KeyChar.ToString <= "9") Then
            Else
                e.Handled = True
            End If
        End If
    End Sub
#End Region

    
End Class
